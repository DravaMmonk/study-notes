# COMP90050 Overleaf Cheatsheet

This is an English A4 landscape cheatsheet with a compact three-column layout.
It starts with a keyword index and then organises the content into 37
database-system topics rather than separate sample-exam or tutorial sections.
Worked examples and answer structures are placed under the concepts they test.

## Overleaf

1. Create a blank Overleaf project.
2. Upload `main.tex` and `content.tex`, or upload
   `COMP90050-cheatsheet-overleaf.zip` as a new project.
3. Set the compiler to **XeLaTeX**.
4. Compile and download the PDF.

The document uses only packages available in a standard Overleaf TeX Live
installation. It does not require external images or fonts.

`main.tex` contains the page style and reusable boxes. `content.tex` contains
the keyword index and examinable notes. Most text-heavy topics use bullet
points, worked examples, causal explanations, answer structures and exam traps
where useful.

## Printing

- A4 landscape
- Actual size / 100% scale
- Duplex, flip on short edge
- Black-and-white output remains readable
